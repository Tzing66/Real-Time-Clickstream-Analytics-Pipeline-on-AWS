from ..es_ES import Provider as SpanishProvider


class Provider(SpanishProvider):
    """Implement lorem provider for ``es_MX`` locale.
    Using the same as in ```es_ES```.
    """
